package com.cg.controllers;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.dao.DaolibraryImpl;

public class DeleteBook extends HttpServlet {
	private static final long serialVersionUID = 1L;
        DaolibraryImpl dao = new DaolibraryImpl();

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		response.setContentType("text/html");
		
		//Book book = new Book();
		//String libraname = request.getParameter("library");
		//Library library = dao.getLibrary(libraname);
		//book.setLibrary(library);
                //book.setBookId(Integer.parseInt(request.getParameter("delboid")));
		//dao.deleteBook(book);
                dao.deleteBook(Integer.parseInt(request.getParameter("delboid")));
		out.println("BookID "+request.getParameter("delboid")+" deleted. ");
		
	}

}
