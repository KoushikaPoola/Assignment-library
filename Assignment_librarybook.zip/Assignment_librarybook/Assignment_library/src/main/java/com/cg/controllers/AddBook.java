package com.cg.controllers;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.dao.DaolibraryImpl;
import com.cg.beans.Book;
import com.cg.beans.Library;


public class AddBook extends HttpServlet {
	private static final long serialVersionUID = 1L;
	DaolibraryImpl dao = new DaolibraryImpl();
    
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		PrintWriter out = response.getWriter();
		response.setContentType("text/html");
		
		Book book = new Book();
		String libraname = request.getParameter("library");
		Library library = dao.getLibrary(libraname);
		book.setLibrary(library);
		
		book.setBookId(Integer.parseInt(request.getParameter("boid")));
		book.setAuthor(request.getParameter("auth"));
		book.setBookName(request.getParameter("bookname"));
		book.setPublisher(request.getParameter("publi"));
		
		dao.addBook(book);
		out.println("Book is added");
		
	}

}
